#!/bin/bash

#前言
echo "你好，此脚本为开源脚本！"
sleep 0.1
echo "所有内容均可复制"
sleep 0.1
echo "不能倒卖!"
sleep 0.05
echo "不能倒卖!!"
sleep 0.05
echo "不能倒卖!!!"
sleep 0.1
echo "作者快手：ba20111022"
sleep 0.1
echo "接下来进入程序"
#密码程序
# 提示输入密码
echo "请输入密码："
read -s password

# 检查密码是否正确
if [[ "$password" == "zhazhajun" ]]; then
    # 提示登录成功
    echo "登录成功！"
else
    # 如果密码错误，退出程序  
    echo "密码错误，程序退出"
    exit 1
fi
# 提示输入选项
echo "请选择一个选项："
    echo "1. 时间"
    echo "2. 日历"
    echo "3. 巴ba"
    echo "4. 退出"

    read choice

    case $choice in
        1)
            #1
    #加载程序
echo -ne '                 \033[1;95m  □□□□□□□□□□0% \r'
sleep 0.10
echo -ne '                 \033[1;95m  ■□□□□□□□□□10% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■□□□□□□□□20% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■□□□□□□□30% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■□□□□□□40% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■□□□□□50% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■□□□□60% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■■□□□70% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■■■□□80% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■■■■□90% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■■■■■100% \r'
sleep 0.1
echo
echo "文件内容加载成功！"
echo "请稍等!"
sleep 0.5
# 获取当前时间
    current_time=$(date +%H:%M)
#输出当前时间
echo 当前时间为：$(date +%H:%M)
echo "加载成功！"
            ;;
        2)
            echo -ne '                 \033[1;95m  □□□□□□□□□□0% \r'
sleep 0.10
echo -ne '                 \033[1;95m  ■□□□□□□□□□10% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■□□□□□□□□20% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■□□□□□□□30% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■□□□□□□40% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■□□□□□50% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■□□□□60% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■■□□□70% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■■■□□80% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■■■■□90% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■■■■■100% \r'
sleep 0.1
echo
echo "文件内容加载成功！"
echo "请稍等!"
sleep 0.5
cal
echo "加载成功！"

            ;;
        3)
        echo -ne '                 \033[1;95m  □□□□□□□□□□0% \r'
sleep 0.10
echo -ne '                 \033[1;95m  ■□□□□□□□□□10% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■□□□□□□□□20% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■□□□□□□□30% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■□□□□□□40% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■□□□□□50% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■□□□□60% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■■□□□70% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■■■□□80% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■■■■□90% \r'
sleep 0.1
echo -ne '                 \033[1;95m  ■■■■■■■■■■100% \r'
sleep 0.1
echo
echo "文件内容加载成功！"
echo "请稍等!"
sleep 0.5
            while true
do
echo "巴ba❤️nb666"#自己使用内容可更改
set +x
let "j=j+1"
done
            
            ;;
        5)
            echo "退出菜单"
            break
            ;;
        *)
            echo "无效的选项，请重新选择"
            ;;
    esac
#此脚本由巴°制作
#快手：ba20111022
#QQ：1712998458
#此脚本开源